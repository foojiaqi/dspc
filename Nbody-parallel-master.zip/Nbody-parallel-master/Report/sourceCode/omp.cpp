#pragma omp parallel num_threads(thread_count) default(shared)
while(!found) {        
    calculate_hash()

    if hash is valid
        found = true
}        
